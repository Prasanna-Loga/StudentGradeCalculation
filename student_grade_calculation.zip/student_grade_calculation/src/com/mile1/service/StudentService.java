package com.mile1.service;

import com.mile1.bean.Student;
import com.mile1.exception.NullNameException;

public class StudentService {
	int c;
	public int findNumberOfNullMarks(Student data[])
	{
		
		try
		{
			c=0;
		for(int i=0;i<data.length;i++)
		{
			if(data[i]!=null)
			if(data[i].getMarks()==null)
				c++;
		} 
		}
		finally{
		return c;
		}
	}
	
	public int findNumberOfNullNames(Student data [])
	{
		try
		{
			c=0;
			
		for(int i=0;i<data.length;i++)
		{
			if(data[i]!=null)
			if(data[i].getName()==null)
				c++;
		}
		}
		finally{
		return c;
	}
	}
	public int findNumberOfNullObjects(Student data [])
	{
		c=0;
		for(int i=0;i<data.length;i++)
		{
			
			if(data[i]==null)
				c++;
		}
		return c;


}
}
